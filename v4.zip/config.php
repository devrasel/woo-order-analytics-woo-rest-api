<?php
// config.php
date_default_timezone_set('UTC'); // Set default timezone to UTC
// Edit these values for your environment

// WooCommerce REST API
// Use full site URL without trailing slash, example: https://example.com
define('WC_SITE_URL', 'https://dev.nxtmotors.com');
define('WC_API_NAMESPACE', '/wp-json/wc/v3');
define('WC_CONSUMER_KEY', 'ck_5e4719d408086fbe895b54532aee654fbfc883c7');
define('WC_CONSUMER_SECRET', 'cs_1f5fcce6d68fba5546e898e313fcc917f9f22c42');

// Authentication Credentials
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'adminpass'); // IMPORTANT: Change this to a strong, unique password in a production environment!

// DB (PDO)
$dbHost = '127.0.0.1';
$dbName = 'nxtapp';
$dbUser = 'root';
$dbPass = 'root';

try {
    $pdo = new PDO("mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4", $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Exception $e) {
    die('DB Connection failed: ' . $e->getMessage());
}

// App settings
// per-page (Woo REST max 100)
define('WC_PER_PAGE', 100);
// Base currency for display/conversion
define('BASE_CURRENCY', 'USD');