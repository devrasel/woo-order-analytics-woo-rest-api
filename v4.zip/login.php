<?php
session_start();
require_once __DIR__ . '/config.php';

$response = ['success' => false];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $username = $input['username'] ?? null;
    $password = $input['password'] ?? null;

    if ($username === ADMIN_USERNAME && $password === ADMIN_PASSWORD) {
        $_SESSION['user_logged_in'] = true;
        $response['success'] = true;
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>