<?php
// currency_rates.php
// Fixed conversion rates TO BASE_CURRENCY (BASE_CURRENCY = USD in config)
// Example: 1 EUR = 1.10 USD
// Update these with your own fixed rates

return [
    'USD' => 1.00,
    'EUR' => 1.00,
    'GBP' => 1.087,
    'AUD' => 0.625,
    'CAD' => 0.682,
    // add more currencies as needed
];